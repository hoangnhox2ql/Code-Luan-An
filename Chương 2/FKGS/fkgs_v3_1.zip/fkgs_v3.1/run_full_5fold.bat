@echo off
REM Chay DAY DU 5 fold cho ca tieu duong va benh tim, cung ma nguon, roi kiem tra
cd /d %~dp0
python run_all.py --dataset all
pause
