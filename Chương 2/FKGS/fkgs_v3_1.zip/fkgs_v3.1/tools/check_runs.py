"""Kiểm tra các run trong results/ có đủ điều kiện để báo cáo cùng nhau:
chế độ đầy đủ (không QUICK), K = 5 fold, đủ mọi bước, CÙNG mã nguồn và cùng cấu hình chung giữa các bộ dữ liệu,
và E2 có đủ K fold cho mỗi phương pháp.

    python tools/check_runs.py            # mã thoát 0 = đạt
"""
import json, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import config as C

STEPS = ["PREPROCESS", "E1", "E2", "E3", "E4", "PUB", "REPORT"]
SHARED = ["kfold", "scale", "fisa", "sampling", "e1", "e2", "e3", "e4", "pub", "fuzzy_quantiles"]


def main():
    ok, mans = True, {}
    for ds in C.DATASETS:
        p = os.path.join(ROOT, "results", ds, "manifest.json")
        if not os.path.exists(p):
            print(f"[LỖI] {ds}: chưa có manifest (chưa chạy)"); ok = False; continue
        m = json.load(open(p, encoding="utf-8")); mans[ds] = m; cfg = m["config"]
        bad = []
        if cfg.get("quick"):
            bad.append("chế độ QUICK")
        if cfg["kfold"]["K"] != 5:
            bad.append(f"K = {cfg['kfold']['K']}")
        miss = [s for s in STEPS if s not in m.get("steps", {})]
        if miss:
            bad.append(f"thiếu bước {miss}")
        e2p = os.path.join(ROOT, "results", ds, "E2_results.json")
        if os.path.exists(e2p):
            e2 = json.load(open(e2p, encoding="utf-8"))
            folds = {r.get("fold") for r in e2.get("per_fold", e2.get("rows", [])) if isinstance(r, dict)}
            folds.discard(None)
            if folds and len(folds) != cfg["kfold"]["K"]:
                bad.append(f"E2 có {len(folds)} fold")
        print(f"[{'ĐẠT' if not bad else 'LỖI'}] {ds}: run {m['run_id']}, mã {m['code_sha256'][:12]}, "
              f"K={cfg['kfold']['K']}, quick={cfg.get('quick')}" + (f" -> {'; '.join(bad)}" if bad else ""))
        ok &= not bad
    if len(mans) > 1:
        hashes = {m["code_sha256"] for m in mans.values()}
        if len(hashes) > 1:
            print("[LỖI] các bộ dữ liệu được chạy bằng MÃ NGUỒN KHÁC NHAU -> chạy lại: python run_all.py --dataset all")
            ok = False
        a, b = list(mans.values())[:2]
        diff = [k for k in SHARED if a["config"].get(k) != b["config"].get(k) and k not in ("scale",)]
        if diff:
            print(f"[LỖI] cấu hình chung khác nhau giữa các bộ dữ liệu: {diff}"); ok = False
    print("KẾT LUẬN:", "ĐỦ ĐIỀU KIỆN BÁO CÁO" if ok else "CHƯA ĐẠT")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
